<?php
	require "user-data.php";

	$user_id = $_SESSION['user_id'];
	$user_email = $_SESSION['user_email'];
	$user_password = $_SESSION['user_password'];
	if($user_id != false && $user_email != false && $user_password != false){
	    $sql = "SELECT * FROM user WHERE user_email = '$user_email'";
    	$run_Sql = mysqli_query($connection, $sql);
    	if($run_Sql){
        	$fetch_info = mysqli_fetch_assoc($run_Sql);
        	$user_status = $fetch_info['user_status'];
        	$user_code = $fetch_info['user_code'];
        	if($user_status == "verified"){
           		if($user_code != 0){
            	    header('location: user-otp.php');
        	    }
    	    }else{
        	    header('location: book.php');
    	    }
    	}
	}else{
    	header('location: signin.php');
	}
?>