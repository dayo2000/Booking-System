<?php
	require_once "user-data.php";
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>NEUST Booking System - OTP</title>
	<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<script type="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="user-otp.css">
</head>
<body>
	<div class="container">
		<div id="header"></div>
		<div id="sub-1"></div>
		<div id="main">
			<center>
				<form action="user-otp.php" method="post" autocomplete="off">
					<h2>Code Verification</h2>
					<?php
						if(count($errors) > 0){
					?>
					<div class="alert alert-danger text-center">
					    <?php
					        foreach($errors as $showerror){
					            echo $showerror;
					        }
					    ?>
					</div>
					<?php
						} else if(isset($_SESSION['info'])){
					 		echo "<div class='alert alert-success text-center' style='display: block;'>";
					 			echo $_SESSION['info'];
					 		echo "</div>";
						}
					?>
					<input type="number" name="otp" maxlength="6" placeholder="Enter Verification Code" required=""> <br/> <br/>
					<input type="submit" name="check-otp" value="Submit">
				</form>
			</center>
		</div>
		<div id="sub-2"></div>
		<div id="footer"></div>
	</div>
</body>
</html>