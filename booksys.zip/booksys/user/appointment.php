<?php
    include("connection.php");

    $user = $_POST['user'];
    $date = $_POST['date'];
    $schedule = $_POST['schedule'];
    $branch = $_POST['branch'];
    $purpose = $_POST['purpose'];
    $destination = $_POST['destination'];
    $status = $_POST['status'];

    $sql = "INSERT INTO appointments (user_email, appointment_date, appointment_branch, appointment_sched, appointment_purpose, appointment_destination, appointment_status) VALUES ('$user', '$date', '$branch', '$schedule', '$purpose', '$destination', '$status')";

    if (mysqli_query($connection, $sql)) {
        header('location: transaction.php');
    }
?>