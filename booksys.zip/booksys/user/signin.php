<?php
	require_once "user-data.php";
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>NEUST Booking System - Sign In</title>
	<script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<script type="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="signup.css">
</head>
<body>
	<div class="container">
		<div id="navbar">
			<nav>
				<a href="signin.php">
					<img src="logo.png">
				</a>
				<h1>NUEVA ECIJA UNIVERSITY OF SCIENCE AND TECHNOLOGY</h1>
				<p id="header-place">ISO 9001:2005 CERTIFIED</p>
			</nav>
		</div>
		<div id="background"></div>
		<div id="picture">
			<img src="image.png">
		</div>
		<div id="form">
			<center>
				<form method="post">
					<div id="text-5">
						<h2>SIGN IN</h2>
					</div>
					<input type="email" name="email" maxlength="50" placeholder="Email Address" required=""> <br/>
					<input type="password" name="password" maxlength="12" placeholder="Password" required=""> <br/> <br/>
					<input type="submit" name="signin" value="SIGN IN">
					<?php
						if(count($errors) > 0){
					?>
					<div class="alert alert-danger text-center" style="padding: 15px; margin-top: 2%; font-size: 14px; background-color: #FFCDD2; color: #C62828; width: 55%;">
						<?php
					        foreach($errors as $showerror){
					            echo $showerror;
					        }
				        ?>
				    </div>
					<?php
						}
					?>
					<p id="text-4">Doesn't have an account? <a href="signup.php">Sign up.</a></p>
				</form>
			</center>
		</div>
		<div id="contactheader">
			<div id="text-1">
				<h2>Get in touch!</h2>
				<p>Have a question or need assistance?</p>
				<p>We are here to help you with anything you need.</p>
			</div>
		</div>
		<div id="contant1"></div>
		<div id="contact2">
			<center>
				<div id="contact-number">
					<i class="fas fa-solid fa-phone"></i>
					<p>Have any concerns?</p>
					<p>You can call us in this number.</p>
					<br/>
					<p>(044) 463 0226</p>
				</div>
			</center>
		</div>
		<div id="contact3">
			<center>
				<div id="contact-social">
					<i class="fas fa-solid fa-user"></i>
					<p>Come visit us at our official Facebook Page and</p>
					<p>website where you can learn more about us.</p>
					<div id="social-icons">
						<a href="https://www.facebook.com/OfficialNEUST"><i class="fa-brands fa-facebook"></i></a>
						<a href="https://neust.edu.ph/"><i class="fa-solid fa-desktop"></i></a>
						<a href="https://www.youtube.com/channel/UCRbQjvCeRk-FHz_uvyVBM-g"><i class="fa-brands fa-youtube"></i></a>
					</div>
				</div>
			</center>
		</div>
		<div id="contact4">
			<center>
				<div id="contact-email">
					<i class="fas fa-solid fa-envelope"></i>
					<p>Need assistance on something?</p>
					<p>Use this email address to send your concerns.</p>
					<br/>
					<p>neustmain@neust.edu.ph</p>
				</div>
			</center>
		</div>
		<div id="contact5"></div>
		<footer></footer>
	</div>
</body>
</html>