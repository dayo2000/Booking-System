<?php
	include("session.php");
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>NEUST Booking System - Transaction</title>
	<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<script type="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="transaction.css">
</head>
<body>
	<div class="container">
		<div id="header">
			<div id="header-content">
				<table>
					<tr>
						<td>
							<?php
								$select = mysqli_query($connection, "SELECT * FROM user WHERE user_id = '$_SESSION[user_id]'");
								while ($row = mysqli_fetch_array($select)) {
							?>

							<a href="#" class="click-profile"><p><?php echo $row['user_firstname'] ." " .$row['user_lastname']; ?></p></a>
							
							<?php
								}
							?>
						</td>
						<td><img src="profile.png"></td>
					</tr>
				</table>	
			</div>
		</div>
		<div class="profile-popup">
			<?php
				$select_data = mysqli_query($connection, "SELECT * FROM user WHERE user_id = '$_SESSION[user_id]'");
				while ($count = mysqli_fetch_array($select_data)) {
			?>
			<h2>View Information</h2>
			<center>
				<table>
					<tr>
						<td>Name</td>
						<td>
							<?php
								echo $count['user_firstname'] ." " .$count['user_lastname'];
							?>
						</td>
					</tr>
					<tr>
						<td>Email Address</td>
						<td>
							<?php
								$user_email = $count['user_email'];
								echo $count['user_email'];
							?>
						</td>
					</tr>
				</table>
				<div class="close-btn">
					<button>Close</button>
				</div>
			</center>
			<?php
				}
			?>
		</div>
		<script type="text/javascript">
			$(document).ready(function(){
				$('.click-profile').click(function(){
					$('.profile-popup').css({"opacity":"1", "pointer-events":"auto"});
				});
				$('button').click(function(){
					$('.profile-popup').css({"opacity":"0", "pointer-events":"none"});
				});
			});
		</script>
		<div id="sidebar">
			<nav>
				<a class="btn"><i class="fas fa-bars"></i></a>
				<div class="menu">
					<div class="item"><a href="book.php"><i class="fa-solid fa-calendar-check"></i>Book</a></div>
					<div class="item active"><a href="transaction.php"><i class="fa-solid fa-list"></i>Transaction</a></div>
					<div class="item">
						<a class="sub-btn"><i class="fas fa-gear"></i>Settings <i class="fas fa-angle-right dropdown"></i></a>
						<div class="sub-menu">
							<a href="setting.php" class="sub-item">Update Information</a>
							<a href="password.php" class="sub-item">Change Password</a>
						</div>
					</div>
					<div class="item"><a href="signout.php"><i class="fa-solid fa-right-from-bracket"></i>Sign Out</a></div>
				</div>
			</nav>
		</div>
		<script type="text/javascript">
			$(document).ready(function(){
				$('.sub-btn').click(function(){
					$(this).next('.sub-menu').slideToggle();
					$(this).find('.dropdown').toggleClass('rotate');
				});
			});
			$(document).ready(function(){
				$('.btn').click(function(){
					$(this).next('.menu').slideToggle();
				});
			});
		</script>
		<div id="table">
			<a class="qr" href="#">View Qr Code</a>
			<div class="qr-popup">
				<h2>Qr Code</h2>
				<center>
				<div class="qr-image">
					<?php
						$today = date("Y-m-d");
						$select = mysqli_query($connection, "SELECT * FROM appointments WHERE user_email = '$user_email' AND appointment_date>= $today AND appointment_status = 'Accepted'");
						if (mysqli_num_rows($select) > 0) {
							while ($row = mysqli_fetch_array($select)) {
								$appointment_id = $row['id'];
							}
							echo '
								<img src="qrcode_generator.php?id='. $appointment_id .'" />
							';
						}else{
							echo '<img src="">';
						}
					?>	
				</div>
					<div class="close-btn">
						<button>Close</button>
					</div>
				</center>
			</div>
			<script type="text/javascript">
				$(document).ready(function(){
					$('.qr').click(function(){
						$('.qr-popup').css({"opacity":"1", "pointer-events":"auto"});
					});
					$('button').click(function(){
						$('.qr-popup').css({"opacity":"0", "pointer-events":"none"});
					});
				});
			</script>
			<div id="table-content">
				<table>
					<?php
						$select = mysqli_query($connection, "SELECT * FROM appointments WHERE user_email = '$user_email'");
						while ($row = mysqli_fetch_array($select)) {
							$date = $row['appointment_date'];
							$dateToPrint = date('F j, Y', strtotime($date));
					?>
					<tr>
						<td class="td-name">Date</td>
						<td class="td-content">
							<?php
								echo $dateToPrint;
							?>
						</td>
					</tr>
					<tr>
						<td class="td-name">Campus</td>
						<td class="td-content">
							<?php
								echo $row['appointment_branch'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-name">Schedule</td>
						<td class="td-content">
							<?php
								echo $row['appointment_sched'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-name">Time</td>
						<td class="td-content">
							<?php
								if($row['appointment_sched'] == "AM"){
									echo "8:00 AM - 12:00 NN";
								}else{
									echo "1:00 PM - 5:00 PM";
								}
							?>
						</td>
					</tr>
					<tr>
						<td class="td-name">Status</td>
						<td class="td-content">
							<?php
								if ($row['appointment_status'] == 'Pending') {
									echo "<p class='status status-pending'>" .$row['appointment_status'] ."</p>";
								} else if ($row['appointment_status'] == 'Accepted') {
									echo "<p class='status status-accept'>" .$row['appointment_status'] ."</p>";
								} else if ($row['appointment_status'] == 'Declined') {
									echo "<p class='status status-decline'>" .$row['appointment_status'] ."</p>";
								}
							?>
						</td>
					</tr>
					<?php
						}
					?>
				</table>
			</div>
		</div>
		<div id="footer"></div>
	</div>
</body>
</html>