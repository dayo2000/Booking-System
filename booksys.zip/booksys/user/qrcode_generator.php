<?php
    include 'phpqrcode/qrlib.php';
    $id = $_GET['id'];
    $code = "NEUST Appointment - $id";
    QRcode::png($code);
?>