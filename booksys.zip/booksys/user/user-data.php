<?php
	ob_start();
	include("connection.php");
	include("log.php");

	//Import PHPMailer classes into the global namespace
	//These must be at the top of your script, not inside a function
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\SMTP;
	use PHPMailer\PHPMailer\Exception;

	session_start();
	$email = "";
	$errors = array();

	//If user click sign up
	if (isset($_POST['signup']) && $_POST['g-recaptcha-response'] !="") {
		$firstname = mysqli_real_escape_string($connection, $_POST['firstname']);
		$lastname = mysqli_real_escape_string($connection, $_POST['lastname']);
		$email = mysqli_real_escape_string($connection, $_POST['email']);
		$password = mysqli_real_escape_string($connection, $_POST['password']);
		$cpassword = mysqli_real_escape_string($connection, $_POST['cpassword']);
		$secretKey = "6LcD6c8aAAAAAPTdHiwiZp9wSJ7hBYLGfoaYJeQ4";
		$Verifyresponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret=' .$secretKey .'&response=' .$_POST['g-recaptcha-response']);
		$responseData = json_decode($Verifyresponse);

		if ($responseData->success) {
			$pattern_name = "/^[\s|0-9]*$/";
      		if (preg_match($pattern_name, $firstname) == 0) {
      			$firstname_validation = "Valid";
      		} else
      			$firstname_validation = "Invalid";

      		if (preg_match($pattern_name, $lastname) == 0) {
      			$lastname_validation = "Valid";
      		} else
      			$lastname_validation = "Invalid";

	    	$pattern_email = "/^[a-zA-Z\d\-\_\.]+@[a-zA-Z]+\.[a-zA-Z\.]+$/";
	    	if (preg_match($pattern_email, $email)) {
      			$email_validation = "Valid";
			} else
      			$email_validation = "Invalid";

	    	$pattern_password = "/^.{8,12}$/";
			if (preg_match($pattern_password, $password)) {
       			$password_validation = "Valid";
			} else 
			    $password_validation = "Invalid";

			if (preg_match($pattern_password, $cpassword)) {
       			$cpassword_validation = "Valid";
			} else 
			    $cpassword_validation = "Invalid";

			$email_check = "SELECT * FROM user WHERE user_email = '$email'";
			$res = mysqli_query($connection, $email_check);
			if(mysqli_num_rows($res) > 0){
			    $errors['email'] = "Email that you have entered already exist!";
			} else if($password !== $cpassword){
	        	$errors['password'] = "Confirm password not matched!";
	    	}else if ($firstname_validation == "Valid" && $lastname_validation == "Valid" && $email_validation == "Valid" && $password_validation == "Valid" && $cpassword_validation == "Valid") {
	    		if(count($errors) === 0){
	    		    $encpass = password_hash($password, PASSWORD_BCRYPT);
	    		    $code = rand(999999, 111111);
	    		    $status = "notverified";
					$insert_data = mysqli_query($connection, "INSERT INTO user (user_firstname, user_lastname, user_email, user_password, user_status, user_code) VALUES ('$firstname', '$lastname', '$email', '$encpass', '$status', '$code')");
					
					if($insert_data){
						//Load Composer's autoloader
						require 'PHPMailer/Exception.php';
						require 'PHPMailer/SMTP.php';
						require 'PHPMailer/PHPMailer.php';

						//Create an instance; passing `true` enables exceptions
						$mail = new PHPMailer(true);

						try {
						    //Server settings
						    $mail->SMTPDebug = SMTP::DEBUG_SERVER;                   
						    $mail->isSMTP();                                         
						    $mail->Host       = 'smtp.gmail.com';                    
						    $mail->SMTPAuth   = true;                                   
						    $mail->Username   = 'neustbookingsystem@gmail.com';         
						    $mail->Password   = 'xmpM9udvHsWj4bq';                      
						    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            
						    $mail->Port       = 465;                                    

						    //Recipients
						    $mail->setFrom('neustbookingsystem@gmail.com', 'NEUST Booking System');
						    $mail->addAddress($email);     

						    //Content
						    $mail->isHTML(true);                                  
						    $mail->Subject = "Email Verification Code";
						    $mail->Body    = "Your verification code is $code";

						    $mail->send();
						    $_SESSION['info'] = "We've sent a verification code to your email - $email";
						    $_SESSION['email'] = $email;
						    $_SESSION['password'] = $password;
						    header('location: user-otp.php');
						    exit();
						} catch (Exception $e) {
						    $errors['otp-error'] = "Failed while sending code!";
						}
					}
				}else{
					$errors['db-error'] = "Failed while inserting data into database!";
				}
			} else
			   	$errors['validation-error'] = "Invalid input(s)!";
		} else
			header('location: signup.php');
	}

	//If user click sign in
	if (isset($_POST['signin'])) {
	    $userIP = $_SERVER['REMOTE_ADDR'];
	    $email = mysqli_real_escape_string($connection, $_POST['email']);
	    $password = mysqli_real_escape_string($connection, $_POST['password']);
	    $check_email = "SELECT * FROM user WHERE user_email = '$email'";
	    $res = mysqli_query($connection, $check_email);
	    if(mysqli_num_rows($res) > 0){
	        $fetch = mysqli_fetch_assoc($res);
	        $fetch_pass = $fetch['user_password'];
	        if(password_verify($password, $fetch_pass)){
	            $_SESSION['user_email'] = $email;
	            $status = $fetch['user_status'];
	            if($status == 'verified'){
	            	$id = $fetch['user_id'];
	            	$_SESSION['user_id'] = $id;
	                $_SESSION['user_email'] = $email;
	                $_SESSION['user_password'] = $password;
	                header('location: book.php');
	                exit();
	            }else {
	                $info = "It looks like you still haven't verified your email - $email";
	                $_SESSION['info'] = $info;
	                header('location: user-otp.php');
	                exit();
	            }
	        }else {
	            $errors['email'] = "Incorrect email or password!";
	        }
	    }else {
	        $errors['email'] = "It looks like you're not yet a member! Click on the bottom link to sign up.";
	    }

	    if ($_SERVER['REQUEST_METHOD'] === "POST") {
	    	$email = $_POST['email'];
	    	$log = "The User Entered: ($email)" ;
	    	logger($log);
	    }
	}

	//if user click verification code submit button
	if(isset($_POST['check-otp'])){
	    $_SESSION['info'] = "";
	    $otp_code = mysqli_real_escape_string($connection, $_POST['otp']);
	    $check_code = "SELECT * FROM user WHERE user_code = $otp_code";
	    $code_res = mysqli_query($connection, $check_code);
	    if(mysqli_num_rows($code_res) > 0){
	        $fetch_data = mysqli_fetch_assoc($code_res);
	        $fetch_code = $fetch_data['user_code'];
	        $email = $fetch_data['user_email'];
	        $code = 0;
	        $status = "verified";
	        $update_otp = "UPDATE user SET user_code = $code, user_status = '$status' WHERE user_code = $fetch_code";
	        $update_res = mysqli_query($connection, $update_otp);
	        if($update_res){
	            $_SESSION['user_id'] = $fetch_data['user_id'];
	            $_SESSION['user_email'] = $email;
	            $_SESSION['user_password'] = $fetch_data['user_password'];
	            header('location: book.php');
	            exit();
	        }else{
	            $errors['otp-error'] = "Failed while updating code!";
	        }
	    }else{
	        $errors['otp-error'] = "You've entered incorrect code!";
	    }
	}
?>