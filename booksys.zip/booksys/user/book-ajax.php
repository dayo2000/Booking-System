<?php
    include("connection.php");

    $date = $_POST['date'];
    $schedule = $_POST['schedule'];
    $branch = $_POST['branch'];
    $email = $_POST['email'];

    $sql = "SELECT * FROM holidays WHERE school_branch='$branch' AND date_holiday='$date'";
    $result = mysqli_query($connection, $sql);

    if (mysqli_num_rows($result) == 0) {
        $today = date("Y-m-d");
        $sql = "SELECT * FROM appointments WHERE user_email='$email' AND appointment_date >= '$today'";
        $result = mysqli_query($connection, $sql);
        $row = mysqli_fetch_array($result);

        $appointment_sched = $row[0];

        if($appointment_sched == 0){
            $sql = "SELECT count(*) FROM appointments WHERE appointment_date='$date' AND appointment_branch='$branch' AND appointment_sched='$schedule'";
            $result = mysqli_query($connection, $sql);
            $row = mysqli_fetch_array($result);

            $total = $row[0];
            if($total >= 100){
                echo '
                    <div class="appointment-details">
                        <h2 style="text-align: center;">The number of appointments on this schedule have exceeded. </h2>
                        <p>Please choose another date and schedule</p>
                    </div>
                ';
            }else{
                echo '
                    <div class="appointment-details">
                        <div class="appointment-title">
                            <h2>Appointment Details</h2>
                        </div>
                        <div class="appointment-info">
                            <div class="appointment-info-row">
                                <p>Date: </p>
                                <span>'.date('F j, Y', strtotime($date)).'</span>
                            </div>
                            <div class="appointment-info-row">
                                <p>Branch: </p>
                                <span>'.$branch.'</span>
                            </div>
                            <div class="appointment-info-row">
                                <p>Schedule: </p>
                                <span>'.$schedule.'</span>
                            </div>
                            <div class="appointment-info-row">
                                <p>Current number of confirmed appointments: </p>
                                <span>'.$total.'</span>
                            </div>
                        </div>
                        <form method="POST" action="appointment.php">
                            <input type="text" name="user" id="user" value="" hidden>
                            <input type="text" name="branch" id="branch" value="'.$branch.'" hidden>
                            <input type="text" name="date" id="date" value="'.$date.'" hidden>
                            <input type="text" name="schedule" id="schedule" value="'.$schedule.'" hidden>
                            <input type="text" name="purpose" id="purpose" placeholder="Purpose">
                            <input type="text" name="destination" id="destination" placeholder="Destination">
                            <input type="text" name="status" id="status" value="Pending" hidden>
                            <button type="submit" class="submit-appointment">Create Appointment</button>
                        </form>
                    </div>
                    <style>
                        .appointment-title {text-align: center;}

                        .appointment-info-row {display: flex;flex-direction: row;align-items: center;}
                        
                        .appointment-info-row p {width: 50%}
                        
                        .appointment-info .appointment-info-row span {width: 50%; font-weight: 600}

                        .submit-appointment {width: 100%;margin: auto;}

                        #purpose{
                            width: 100%;
                            margin-top: 1%;
                            margin-bottom: 1%;
                            padding: 10px;
                            box-sizing: border-box;
                            border: 1px solid #111B42;
                            background-color: #fff;
                            color: #111B42;
                        }

                        #destination{
                            width: 100%;
                            margin-top: 1%;
                            margin-bottom: 10%;
                            padding: 10px;
                            box-sizing: border-box;
                            border: 1px solid #111B42;
                            background-color: #fff;
                            color: #111B42;
                        }
                    </style>
                ';
            }
        }else{
            echo '
                <div class="appointment-details">
                    <h2 style="text-align: center;">Cannot View Appointments</h2>
                    <p>You already have an appointment. Click <a href="appointment.php">here</a> to view your appointment</p>
                </div>
            ';
        }

        
    }else{
        while($row = mysqli_fetch_assoc($result)) {
            $holiday_name = $row["holiday_name"];
        }
        echo '
            <div class="appointment-details">
                <h2 style="text-align: center;">'.$holiday_name.'</h2>
                <p>The '.$branch.' is closed on '.date('F j, Y',strtotime($date)).'</p>
            </div>
        ';
    }

?>