<?php
	include("session.php");
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>NEUST Booking System - Book</title>
	<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<script src='https://cdn.jsdelivr.net/npm/moment@2.27.0/min/moment.min.js'></script>
	<script type="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.10.1/main.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.10.1/locales-all.min.js"></script>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fullcalendar@5.10.1/main.min.css">
	<link rel="stylesheet" type="text/css" href="book.css">
	<script>

      document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendar');
		var tomorrow = new Date();
		tomorrow.setDate(tomorrow.getDate()+1);
		var currentDate = tomorrow.toISOString().slice(0,10);
		maxDate = currentDate;
        var calendar = new FullCalendar.Calendar(calendarEl, {
          	initialView: 'dayGridMonth',
		  	events: [
				{
					groupId: 'monday1',
					daysOfWeek: [ '1' ],
					title: 'Monday AM',
					startTime: '08:00:00',
					endTime: '12:00:00'
				},
				{
					groupId: 'monday2',
					daysOfWeek: [ '1' ],
					title: 'Monday PM',
					startTime: '13:00:00',
					endTime: '17:00:00'
				},
				{
					groupId: 'tuesday1',
					daysOfWeek: [ '2' ],
					title: 'Tuesday AM',
					startTime: '08:00:00',
					endTime: '12:00:00'
				},
				{
					groupId: 'tuesday2',
					daysOfWeek: [ '2' ],
					title: 'Tuesday PM',
					startTime: '13:00:00',
					endTime: '17:00:00'
				},
				{
					groupId: 'wed1',
					daysOfWeek: [ '3' ],
					title: 'Wednesday AM',
					startTime: '08:00:00',
					endTime: '12:00:00'
				},
				{
					groupId: 'wed2',
					daysOfWeek: [ '3' ],
					title: 'Wednesday PM',
					startTime: '13:00:00',
					endTime: '17:00:00'
				},
				{
					groupId: 'thursday1',
					daysOfWeek: [ '4' ],
					title: 'Thursday AM',
					startTime: '08:00:00',
					endTime: '12:00:00'
				},
				{
					groupId: 'thursday2',
					daysOfWeek: [ '4' ],
					title: 'Thursday PM',
					startTime: '13:00:00',
					endTime: '17:00:00'
				},
				{
					groupId: 'friday1',
					daysOfWeek: [ '5' ],
					title: 'Friday AM',
					startTime: '08:00:00',
					endTime: '12:00:00'
				},
				{
					groupId: 'friday2',
					daysOfWeek: [ '5' ],
					title: 'Friday PM',
					startTime: '13:00:00',
					endTime: '17:00:00'
				},
			],
			validRange: {
				start: currentDate
			},
			eventClick: function(info) {
				var eventDate = info.event.start;
				var schedule = info.event.startStr;
				var hour_time = schedule.substring(
					schedule.indexOf("T") + 1, 
					schedule.lastIndexOf(":")
				);
				var sched = hour_time.substring(0,2);
				var schedule = (sched == "08") ? "AM" : "PM";
				$.ajax({
					type: 'POST',
					url: 'book-ajax.php',
					data: { 
						date: eventDate.toISOString().slice(0, 10),
						schedule: schedule,
						branch: $('#branch').find(":selected").text(),
						email: $('#user_mail').val()
					},
					success: function(data)
					{
						$('.booking-details').html(data);
						$('#user').val($('#user_mail').val());
					}
				});
			},
			editable: false,
        });
        calendar.render();
		$(".fc-event-time").css('display', 'none');
      });

    </script>
</head>
<body>
	<div class="container">
		<div id="header">
			<div id="header-content">
				<table>
					<tr>
						<td>
							<?php
								$select = mysqli_query($connection, "SELECT * FROM user WHERE user_id = '$_SESSION[user_id]'");
								while ($row = mysqli_fetch_array($select)) {
							?>

							<a href="#" class="click-profile"><p><?php echo $row['user_firstname'] ." " .$row['user_lastname']; ?></p></a>
							
							<?php
								}
							?>
						</td>
						<td><img src="profile.png"></td>
					</tr>
				</table>	
			</div>
		</div>
		<div class="profile-popup">
			<?php
				$select_data = mysqli_query($connection, "SELECT * FROM user WHERE user_id = '$_SESSION[user_id]'");
				while ($count = mysqli_fetch_array($select_data)) {
			?>
			<h2>View Information</h2>
			<center>
				<table>
					<tr>
						<td>Name</td>
						<td>
							<?php
								echo $count['user_firstname'] ." " .$count['user_lastname'];
							?>
						</td>
					</tr>
					<tr>
						<td>Email Address</td>
						<td>
							<?php
								echo trim($count['user_email'], " ");
							?>
							<input type="text" name="user_mail" id="user_mail" value="<?php echo trim($count['user_email'], " "); ?>" hidden>
						</td>
					</tr>
				</table>
				<div class="close-btn">
					<button>Close</button>
				</div>
			</center>
			<?php
				}
			?>
		</div>
		<script type="text/javascript">
			$(document).ready(function(){
				$('.click-profile').click(function(){
					$('.profile-popup').css({"opacity":"1", "pointer-events":"auto"});
				});
				$('button').click(function(){
					$('.profile-popup').css({"opacity":"0", "pointer-events":"none"});
				});
			});
		</script>
		<div id="sidebar">
			<nav>
				<a class="btn"><i class="fas fa-bars"></i></a>
				<div class="menu">
					<div class="item active"><a href="book.php"><i class="fa-solid fa-calendar-check"></i>Book</a></div>
					<div class="item"><a href="transaction.php"><i class="fa-solid fa-list"></i>Transaction</a></div>
					<div class="item">
						<a class="sub-btn"><i class="fas fa-gear"></i>Settings <i class="fas fa-angle-right dropdown"></i></a>
						<div class="sub-menu">
							<a href="setting.php" class="sub-item">Update Information</a>
							<a href="password.php" class="sub-item">Change Password</a>
						</div>
					</div>
					<div class="item"><a href="signout.php"><i class="fa-solid fa-right-from-bracket"></i>Sign Out</a></div>
				</div>
			</nav>
		</div>
		<script type="text/javascript">
			$(document).ready(function(){
				$('.sub-btn').click(function(){
					$(this).next('.sub-menu').slideToggle();
					$(this).find('.dropdown').toggleClass('rotate');
				});
			});
			$(document).ready(function(){
				$('.btn').click(function(){
					$(this).next('.menu').slideToggle();
				});
			});
		</script>
		<div class="calendar-section">
			<div class="select-branch">
				<select name="brance" id="branch">
					<option selected>Sumacab Campus</option>
					<option>General Tinio Street Campus</option>
					<option>Atate Campus</option>
					<option>Fort Magsaysay Campus</option>
					<option>Gabaldon Campus</option>
					<option>San Isidro Campus</option>
				</select>
			</div>
			<div id='calendar'></div>
		</div>
		<div class="booking-details"></div>
		<div id="footer"></div>
	</div>
</body>
</html>