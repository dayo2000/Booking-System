<?php
	include("connection.php");
	session_start();

	$id = $_SESSION['admin_id'];
	$email = $_SESSION['admin_email'];
	$password = $_SESSION['admin_password'];
	$branch = $_SESSION['admin_branch'];
	if($id == false && $email == false && $password == false && $branch == false){
    	header('location: signin.php');
	}
?>