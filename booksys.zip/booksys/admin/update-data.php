<?php
	include("connection.php");
	include("session.php");
	$messages = array();
	$errors = array();
	$error = array();

	if (isset($_POST['save-name'])) {
	    $firstname = $_POST['firstname'];
		$lastname = $_POST['lastname'];

		$pattern_name = "/^[\s|0-9]*$/";
      	if (preg_match($pattern_name, $firstname) == 0) {
      		$firstname_validation = "Valid";
      	} else
      		$firstname_validation = "Invalid";

      	if (preg_match($pattern_name, $lastname) == 0) {
      		$lastname_validation = "Valid";
	   	} else
     		$lastname_validation = "Invalid";

		if ($firstname_validation == "Valid" && $lastname_validation == "Valid"){
			$update = mysqli_query($connection, "UPDATE admin SET admin_firstname = '$firstname', admin_lastname = '$lastname' WHERE admin_id = '$_SESSION[admin_id]'");
			if ($update){
				$messages['info'] = "Name successfully changed!";
			} else
				$errors['validation'] = "Something went wrong!";
		}else
			$errors['validation'] = "Invalid input(s)!";
	}

	if (isset($_POST['save-email'])) {
	    $email = $_POST['email'];

		$pattern_email = "/^[a-zA-Z\d\-\_\.]+@[a-zA-Z]+\.[a-zA-Z\.]+$/";
		if (preg_match($pattern_email, $email)) {
			$email_validation = "Valid";
		} else
			$email_validation = "Invalid";

		$email_check = "SELECT * FROM admin WHERE admin_email = '$email'";
		$res = mysqli_query($connection, $email_check);
		if(mysqli_num_rows($res) > 0){
		    $error['email'] = "Email that you have entered already exist!";
		} else if ($email_validation == "Valid"){
			$update = mysqli_query($connection, "UPDATE admin SET admin_email = '$email' WHERE admin_id = '$_SESSION[admin_id]'");
			if ($update){
				echo "<script>alert('Email successfully changed! Your account will automatically sign out after you click okay. Please sign in again with your new email.');window.location.href='signout.php';</script>";
			} else
				$error['validation'] = "Something went wrong!";
		}else
			$error['validation'] = "Invalid input(s)!";
	}

	if (isset($_POST['save-password'])) {
		$password = $_POST['password'];
		$cpassword = $_POST['cpassword'];

	    $pattern_password = "/^.{8,12}$/";
		if (preg_match($pattern_password, $password)) {
       		$password_validation = "Valid";
		} else 
		    $password_validation = "Invalid";

		if (preg_match($pattern_password, $cpassword)) {
   			$cpassword_validation = "Valid";
		} else 
		    $cpassword_validation = "Invalid";

        if ($password_validation == "Valid" && $cpassword_validation == "Valid"){
       		if($password !== $cpassword){
	        	$errors['password'] = "Confirm Password not matched!";
	        } else if(count($errors) === 0){
		    	$encpass = password_hash($password, PASSWORD_BCRYPT);
		    	$update = mysqli_query($connection, "UPDATE admin SET admin_password = '$encpass' WHERE admin_id = '$_SESSION[admin_id]'");
		    	if ($update) {
		    		echo "<script>alert('Password successfully changed! Your account will automatically sign out after you click okay. Please sign in again with your new password.');window.location.href='signout.php'</script>";
	    		} else {
	    	    	$errors['validation'] = "Something went wrong!";
	    		}
	    	}
		} else
           	$errors['validation'] = "Invalid input(s)!";
   	}
?>