<?php
	$connection = mysqli_connect("localhost", "root", "", "booksys");
	
	if(!$connection){
		die("ConnectionFailed:".mysqli_connect_error());
	}
?>