<?php
	include("add-data.php");
	$messages = array();
	$errors = array();

	//if admin click inactive
	if(isset($_GET['inactive'])) {
		$admin_id = $_GET['inactive'];
		$status = "inactive";
		$update_data = mysqli_query($connection, "UPDATE admin SET admin_status = '$status' WHERE admin_id = '$admin_id'");
										
		if ($update_data){
			$messages['info'] = "User account has been set to be inactive!";
		} else{
		    $errors['db-error'] = "Failed while updating data in the database!";
		}
	}

	//if admin click lock
	if(isset($_GET['lock'])) {
		$admin_id = $_GET['lock'];
		$status = "lock";
		$update_data = mysqli_query($connection, "UPDATE admin SET admin_status = '$status' WHERE admin_id = '$admin_id'");
											
		if ($update_data){
		    $messages['info'] = "User account has been locked!";
		} else{
		    $errors['db-error'] = "Failed while updating data in the database!";
		}
	}


	//if admin click delete
	if(isset($_GET['delete'])) {
		$admin_id = $_GET['delete'];
		$delete_data = mysqli_query($connection, "DELETE FROM admin WHERE admin_id = '$admin_id'");
										
		if ($delete_data){
		    $messages['info'] = "User account has been deleted!";
		} else{
	    	$errors['db-error'] = "Failed while deleting data in the database!";
		}
	}

	//if admin click active
	if(isset($_GET['active'])) {
		$admin_id = $_GET['active'];
		$status = "active";
		$update_data = mysqli_query($connection, "UPDATE admin SET admin_status = '$status' WHERE admin_id = '$admin_id'");
			
		if ($update_data){
		    $messages['info'] = "User account has been activated!";
		} else{
		    $errors['db-error'] = "Failed while updating data in the database!";
		}
	}
?>