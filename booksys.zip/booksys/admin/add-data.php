<?php
	include("connection.php");
	include("session.php");
	$messages = array();
	$message = array();
	$errors = array();
	$error = array();

	//If user click create (office head)
	if (isset($_POST['create-head'])) {
		$firstname = mysqli_real_escape_string($connection, $_POST['firstname']);
		$lastname = mysqli_real_escape_string($connection, $_POST['lastname']);
		$email = mysqli_real_escape_string($connection, $_POST['email']);
		$password = mysqli_real_escape_string($connection, $_POST['password']);
		$cpassword = mysqli_real_escape_string($connection, $_POST['cpassword']);
		$branch = $_SESSION['admin_branch'];

		$pattern_name = "/^[\s|0-9]*$/";
		if (preg_match($pattern_name, $firstname) == 0) {
			$firstname_validation = "Valid";
		} else
			$firstname_validation = "Invalid";

		if (preg_match($pattern_name, $lastname) == 0) {
			$lastname_validation = "Valid";
		} else
			$lastname_validation = "Invalid";

		if (preg_match($pattern_name, $branch) == 0) {
      		$branch_validation = "Valid";
      	} else
      		$branch_validation = "Invalid";

		$pattern_email = "/^[a-zA-Z\d\-\_\.]+@[a-zA-Z]+\.[a-zA-Z\.]+$/";
		if (preg_match($pattern_email, $email)) {
			$email_validation = "Valid";
		} else
			$email_validation = "Invalid";

		$pattern_password = "/^.{8,12}$/";
		if (preg_match($pattern_password, $password)) {
			$password_validation = "Valid";
		} else 
			$password_validation = "Invalid";

		if (preg_match($pattern_password, $cpassword)) {
       		$cpassword_validation = "Valid";
		} else 
		    $cpassword_validation = "Invalid";

		$email_check = "SELECT * FROM admin WHERE admin_email = '$email'";
		$res = mysqli_query($connection, $email_check);
		if(mysqli_num_rows($res) > 0){
			$errors['email'] = "Email that you have entered already exist!";
		} else if ($firstname_validation == "Valid" && $lastname_validation == "Valid" && $email_validation == "Valid" && $password_validation == "Valid" && $cpassword_validation == "Valid" && $branch_validation == "Valid") {
			if($password !== $cpassword){
				$errors['password'] = "Confirm password not matched!";
			}else if(count($errors) === 0){
				$encpass = password_hash($password, PASSWORD_BCRYPT);
				$type = "Office Head";
				$status = "active";
				$insert_data = mysqli_query($connection, "INSERT INTO admin (admin_firstname, admin_lastname, admin_email, admin_password, admin_type, admin_status, admin_branch) VALUES ('$firstname', '$lastname', '$email', '$encpass', '$type', '$status', '$branch')");
				if ($insert_data){
      				echo "<script>alert('User successfully created!');window.location.href='office-head-admin.php'</script>";
      			} else{
      				$errors['db-error'] = "Failed while inserting data in the database!";
      			}
			}
		} else{
      		$errors['validation-error'] = "Invalid input(s)!";
      	}
	}

	//If user click create (guard)
	if (isset($_POST['create-guard'])) {
		$firstname = mysqli_real_escape_string($connection, $_POST['firstname']);
		$lastname = mysqli_real_escape_string($connection, $_POST['lastname']);
		$email = mysqli_real_escape_string($connection, $_POST['email']);
		$password = mysqli_real_escape_string($connection, $_POST['password']);
		$cpassword = mysqli_real_escape_string($connection, $_POST['cpassword']);
		$branch = $_SESSION['admin_branch'];

		$pattern_name = "/^[\s|0-9]*$/";
		if (preg_match($pattern_name, $firstname) == 0) {
			$firstname_validation = "Valid";
		} else
			$firstname_validation = "Invalid";

		if (preg_match($pattern_name, $lastname) == 0) {
			$lastname_validation = "Valid";
		} else
			$lastname_validation = "Invalid";

      	if (preg_match($pattern_name, $branch) == 0) {
      		$branch_validation = "Valid";
      	} else
      		$branch_validation = "Invalid";

		$pattern_email = "/^[a-zA-Z\d\-\_\.]+@[a-zA-Z]+\.[a-zA-Z\.]+$/";
		if (preg_match($pattern_email, $email)) {
			$email_validation = "Valid";
		} else
			$email_validation = "Invalid";

		$pattern_password = "/^.{8,12}$/";
		if (preg_match($pattern_password, $password)) {
			$password_validation = "Valid";
		} else 
			$password_validation = "Invalid";

		if (preg_match($pattern_password, $cpassword)) {
       		$cpassword_validation = "Valid";
		} else 
		    $cpassword_validation = "Invalid";

		$email_check = "SELECT * FROM admin WHERE admin_email = '$email'";
		$res = mysqli_query($connection, $email_check);
		if(mysqli_num_rows($res) > 0){
			$errors['email'] = "Email that you have entered already exist!";
		} else if ($firstname_validation == "Valid" && $lastname_validation == "Valid" && $email_validation == "Valid" && $password_validation == "Valid" && $cpassword_validation == "Valid" && $branch_validation == "Valid") {
			if($password !== $cpassword){
				$errors['password'] = "Confirm password not matched!";
			}else if(count($errors) === 0){
				$encpass = password_hash($password, PASSWORD_BCRYPT);
				$type = "Guard";
				$status = "active";
				$insert_data = mysqli_query($connection, "INSERT INTO admin (admin_firstname, admin_lastname, admin_email, admin_password, admin_type, admin_status, admin_branch) VALUES ('$firstname', '$lastname', '$email', '$encpass', '$type', '$status', '$branch')");
				if ($insert_data){
      				echo "<script>alert('User successfully created!');window.location.href='guard-admin.php'</script>";
      			} else{
      				$errors['db-error'] = "Failed while inserting data in the database!";
      			}
			}
		} else{
      		$errors['validation-error'] = "Invalid input(s)!";
      	}
	}

	//If user click add holiday
	if (isset($_POST['add'])) {
		$branch = $_SESSION['admin_branch'];
		$date = mysqli_real_escape_string($connection, $_POST['date']);
		$name = mysqli_real_escape_string($connection, $_POST['name']);

		$pattern_name = "/^[\s|0-9]*$/";
      	if (preg_match($pattern_name, $branch) == 0) {
      		$branch_validation = "Valid";
      	} else
      		$branch_validation = "Invalid";

      	if (preg_match($pattern_name, $name) == 0) {
      		$name_validation = "Valid";
      	} else
      		$name_validation = "Invalid";

		$pattern_date = "/^.{1,30}$/";
      	if (preg_match($pattern_date, $date)) {
      		$date_validation = "Valid";
      	} else
      		$date_validation = "Invalid";

		if ($branch_validation == "Valid" && $name_validation == "Valid" && $date_validation == "Valid") {
      		$insert_data = mysqli_query($connection, "INSERT INTO holidays (school_branch, date_holiday, holiday_name) VALUES ('$branch', '$date', '$name')");
      		if ($insert_data){
      			$messages['info'] = "Holiday successfully added!";
      		} else{
      			$errors['db-error'] = "Failed while inserting data in the database!";
      		}
      	} else{
      		$errors['validation-error'] = "Invalid input(s)!";
      	}
	}

	if(isset($_GET['delete'])) {
		$id = $_GET['delete'];
		$delete_data = mysqli_query($connection, "DELETE FROM holidays WHERE id = '$id'");
		
		if ($delete_data){
		    $message['info'] = "Holiday has been deleted!";
		} else{
		    $error['db-error'] = "Failed while deleting data in the database!";
		}
	}
?>