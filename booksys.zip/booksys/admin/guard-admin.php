<?php
	require_once "guard-data.php";
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Guards</title>
	<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<script type="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="admin.css">
</head>
<body>
	<div class="container">
		<div id="header">
			<div id="header-content">
				<table>
					<tr>
						<td>
							<?php
								$select = mysqli_query($connection, "SELECT * FROM admin WHERE admin_id = '$_SESSION[admin_id]'");
								while ($row = mysqli_fetch_array($select)) {
							?>

							<p><?php echo $row['admin_firstname'] ." " .$row['admin_lastname'] ." - " .$row['admin_type']; ?></p>
							
							<?php
								}
							?>
						</td>
						<td><img src="profile.png"></td>
					</tr>
				</table>	
			</div>
		</div>
		<div id="sidebar">
			<nav>
				<a class="btn"><i class="fas fa-bars"></i></a>
				<div class="menu">
					<div class="item"><a href="dashboard-admin.php"><i class="fas fa-desktop"></i>Dashboard</a></div>
					<div class="item">
						<a class="sub-btn"><i class="fa-solid fa-users"></i>Users <i class="fas fa-angle-right dropdown"></i></a>
						<div class="sub-menu">
							<a href="office-head-admin.php" class="sub-item">Office Heads</a>
							<a href="guard-admin.php" class="sub-item active">Guards</a>
						</div>
					</div>
					<div class="item">
						<a class="sub-btn"><i class="fas fa-gear"></i>Settings <i class="fas fa-angle-right dropdown"></i></a>
						<div class="sub-menu">
							<a href="setting.php" class="sub-item">General Settings</a>
							<a href="password.php" class="sub-item">Change Password</a>
							<a href="holiday.php" class="sub-item">Add Holidays</a>
						</div>
					</div>
					<div class="item"><a href="signout.php"><i class="fa-solid fa-right-from-bracket"></i>Sign Out</a></div>
				</div>
			</nav>
		</div>
		<script type="text/javascript">
			$(document).ready(function(){
				$('.sub-btn').click(function(){
					$(this).next('.sub-menu').slideToggle();
					$(this).find('.dropdown').toggleClass('rotate');
				});
			});
			$(document).ready(function(){
				$('.btn').click(function(){
					$(this).next('.menu').slideToggle();
				});
			});
		</script>
		<div id="searchbar">
			<div id="searchbar-form" hidden>
				<form method="post">
					<input type="text" name="search-data" placeholder="Search">
					<input type="submit" name="search" value="Search">
				</form>
			</div>
		</div>
		<div id="add">
			<a href="add-guard.php"><i class="fa-solid fa-user-plus"></i> Create a new User</a>
		</div>
		<div id="table">
			<div>
				<?php
					if(count($messages) > 0){
			    ?>
				    <div class="alert alert-danger text-center" style="display: block; width: auto; padding: 15px; color: #388E3C; margin: 0 0 10px 0; background-color: #C8E6C9; font-size: 14px;">
				        <?php
					        foreach($messages as $showmessage){
					            echo $showmessage;
					        }
				        ?>
				    </div>
			    <?php
					} else if(count($errors) > 0){
				?>
					<div class="alert alert-danger text-center" style="display: block; width: auto; padding: 15px; color: #C62828; margin: 0 0 10px 0; background-color: #FFCDD2; font-size: 14px;">
				        <?php
					        foreach($errors as $showerror){
					            echo $showerror;
					        }
				        ?>
				    </div>
				<?php
					}
				?>
				<center>
					<table>
						<thead>
							<tr>
								<th>ID</th>
								<th>Name</th>
								<th>Email Address</th>
								<th>User Role</th>
								<th>Status</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							<?php
								$select_data = mysqli_query($connection, "SELECT * FROM admin WHERE admin_type = 'Guard' AND admin_branch = '$_SESSION[admin_branch]'");

								if ($select_data->num_rows > 0) {
									while ($count = mysqli_fetch_array($select_data)) {
										echo "<tr><td>" .$count['admin_id'] ."</td>";
										echo "<td>" .$count['admin_firstname'] ." " .$count['admin_lastname'] ."</td>";
										echo "<td>" .$count['admin_email'] ."</td>";
										echo "<td>" .$count['admin_type'] ."</td>";
										echo "<td>";
										if ($count['admin_status'] == 'active') {
											echo "<p class='status status-accept'>" .$count['admin_status'] ."</p>";
										} else if($count['admin_status'] == 'inactive'){
											echo "<p class='status status-pending'>" .$count['admin_status'] ."</p>";
										} else if($count['admin_status'] == 'lock'){
											echo "<p class='status status-decline'>" .$count['admin_status'] ."</p>";
										}
										echo "</td>";
										echo "<td>";
							?>

																
							<?php
								if ($count['admin_status'] == 'active') {
									echo "<div class='status-anchor'>";
										echo "<a href='guard-admin.php?inactive=$count[admin_id]'>Inactive</a> /";
										echo "<a href='guard-admin.php?lock=$count[admin_id]'>Account Lock</a> /";
										echo "<a href='guard-admin.php?delete=$count[admin_id]'>Delete</a>";
									echo "</div>";
								} else if ($count['admin_status'] == 'inactive') {
										echo "<div class='status-anchor'>";
											echo "<a href='guard-admin.php?active=$count[admin_id]'>Active</a>";
										echo "</div>";
								} else if ($count['admin_status'] == 'lock') {
										echo "<div class='status-anchor'>";
											echo "<a href='guard-admin.php?active=$count[admin_id]'>Active</a>";
										echo "</div>";
								}
							?>

							<?php
											echo "</td>";
										echo "</tr>";
									} 
								} else{
									echo "<tr><td colspan='8' align='center'>No Data</td></tr>";
								}
							?>
						</tbody>
					</table>
				</center>
			</div>
		</div>
		<div id="footer"></div>
	</div>
</body>
</html>