<?php
	require_once "admin-data.php";
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Sign Up</title>
	<script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<script type="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="signup.css">
</head>
<body>
	<div class="container">
		<div id="left"></div>
		<div id="right">
			<div id="content">
				<center>
					<form method="post">
						<img src="logo.png">
						<h1>NUEVA ECIJA UNIVERSITY</h1>
						<h1>OF SCIENCE AND TECHNOLOGY</h1>
						<br/>
						<h2>SIGN UP</h2>
						<select name="branch">
							<?php
								echo "<option>Sumacab Campus</option>";
								echo "<option>General Tinio Street Campus</option>";
								echo "<option>Atate Campus</option>";
								echo "<option>Fort Magsaysay Campus</option>";
								echo "<option>Gabaldon Campus</option>";
								echo "<option>San Isidro Campus</option>";
							?>
						</select>
						<input type="text" name="firstname" maxlength="50" placeholder="First Name" required="">
						<input type="text" name="lastname" maxlength="50" placeholder="Last Name" required="">
						<input type="email" name="email" maxlength="50" placeholder="Email Address" required="">
						<input type="password" name="password" maxlength="12" placeholder="Password" required="">
						<input type="password" name="cpassword" maxlength="12" placeholder="Confirm Password" required="">
						<div class="g-recaptcha" data-sitekey="6LcD6c8aAAAAADaVTTum0FIoWeWe23haXSk9T1Pt"></div>
						<input type="submit" name="signup" value="SIGN UP">
						<?php
							if(count($errors) > 0){
						?>
						<div class="alert alert-danger text-center" style="padding: 15px; margin-top: 2%; font-size: 14px; background-color: #FFCDD2; color: #C62828; width: 50%;">
							<?php
					        	foreach($errors as $showerror){
					    	        echo $showerror;
						        }
					        ?>
					    </div>
						<?php
							}
						?>
						<p>Already have an account? <a href="signin.php">Sign in.</a></p>
					</form>
				</center>
			</div>
		</div>
	</div>
</body>
</html>