<?php
	ob_start();
	include("connection.php");
	session_start();
	$errors = array();

	//If user click sign up
	if (isset($_POST['signup']) && $_POST['g-recaptcha-response'] !="") {
		$firstname = mysqli_real_escape_string($connection, $_POST['firstname']);
		$lastname = mysqli_real_escape_string($connection, $_POST['lastname']);
		$email = mysqli_real_escape_string($connection, $_POST['email']);
		$password = mysqli_real_escape_string($connection, $_POST['password']);
		$cpassword = mysqli_real_escape_string($connection, $_POST['cpassword']);
		$branch = mysqli_real_escape_string($connection, $_POST['branch']);
		$secretKey = "6LcD6c8aAAAAAPTdHiwiZp9wSJ7hBYLGfoaYJeQ4";
		$Verifyresponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret=' .$secretKey .'&response=' .$_POST['g-recaptcha-response']);
		$responseData = json_decode($Verifyresponse);

		if ($responseData->success) {
			$pattern_name = "/^[\s|0-9]*$/";
      		if (preg_match($pattern_name, $firstname) == 0) {
      			$firstname_validation = "Valid";
      		} else
      			$firstname_validation = "Invalid";

      		if (preg_match($pattern_name, $lastname) == 0) {
      			$lastname_validation = "Valid";
      		} else
      			$lastname_validation = "Invalid";

      		if (preg_match($pattern_name, $branch) == 0) {
      			$branch_validation = "Valid";
      		} else
      			$branch_validation = "Invalid";

	    	$pattern_email = "/^[a-zA-Z\d\-\_\.]+@[a-zA-Z]+\.[a-zA-Z\.]+$/";
	    	if (preg_match($pattern_email, $email)) {
      			$email_validation = "Valid";
			} else
      			$email_validation = "Invalid";

	    	$pattern_password = "/^.{8,12}$/";
			if (preg_match($pattern_password, $password)) {
       			$password_validation = "Valid";
			} else 
			    $password_validation = "Invalid";

			if (preg_match($pattern_password, $cpassword)) {
       			$cpassword_validation = "Valid";
			} else 
			    $cpassword_validation = "Invalid";

			$email_check = "SELECT * FROM admin WHERE admin_email = '$email'";
			$res = mysqli_query($connection, $email_check);
			if(mysqli_num_rows($res) > 0){
			    $errors['email'] = "Email that you have entered already exist!";
			} else if($password !== $cpassword){
	        	$errors['password'] = "Confirm password not matched!";
	    	}else if ($firstname_validation == "Valid" && $lastname_validation == "Valid" && $branch_validation == "Valid" && $email_validation == "Valid" && $password_validation == "Valid" && $cpassword_validation == "Valid") {
	    		if(count($errors) === 0){
	    		    $encpass = password_hash($password, PASSWORD_BCRYPT);
	    		    $type = "Admin";
	    		    $status = "active";
					$insert_data = mysqli_query($connection, "INSERT INTO admin (admin_firstname, admin_lastname, admin_email, admin_password, admin_status, admin_type, admin_branch) VALUES ('$firstname', '$lastname', '$email', '$encpass', '$status', '$type', '$branch')");
					
					if($insert_data){
						$_SESSION['admin_id'] = $id;
	                	$_SESSION['admin_email'] = $email;
	                	$_SESSION['admin_password'] = $password;
						header('location: dashboard-admin.php');
						exit();
					} else{
						$errors['db-error'] = "Failed while inserting data into database!";
						exit();
					}
				}
			} else{
			   	$errors['validation-error'] = "Invalid input(s)!";
			   	exit();
			}
		} else{
			header('location: signup.php');
		}
	}

	//If user click sign in
	if (isset($_POST['signin'])) {
	    $email = mysqli_real_escape_string($connection, $_POST['email']);
	    $password = mysqli_real_escape_string($connection, $_POST['password']);
	    $check_email = "SELECT * FROM admin WHERE admin_email = '$email'";
	    $res = mysqli_query($connection, $check_email);
	    if(mysqli_num_rows($res) > 0){
	        $fetch = mysqli_fetch_assoc($res);
	        $fetch_pass = $fetch['admin_password'];
	        if(password_verify($password, $fetch_pass)){
	            $type = $fetch['admin_type'];
	            $status = $fetch['admin_status'];
	            if ($type == 'Admin') {
	            	if ($status == 'active') {
	            		$id = $fetch['admin_id'];
	            		$branch = $fetch['admin_branch'];
	            		$_SESSION['admin_id'] = $id;
	                	$_SESSION['admin_email'] = $email;
	                	$_SESSION['admin_password'] = $password;
	                	$_SESSION['admin_branch'] = $branch;
	                	header('location: dashboard-admin.php');
	                	exit();
	            	}
	            }else {
	            	$errors['email'] = "You're not an Admin!";
	            }
	        }else {
	            $errors['email'] = "Incorrect email or password!";
	        }
	    }else {
	        $errors['email'] = "Account doesn't exist! Click on the bottom link to sign up.";
	    }
	}
?>