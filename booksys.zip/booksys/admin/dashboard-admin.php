<?php
	require "session.php";
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Dashboard</title>
	<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<script type="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="dashboard.css">
</head>
<body>
	<div class="container">
		<div id="header">
			<div id="header-content">
				<table>
					<tr>
						<td>
							<?php
								$select = mysqli_query($connection, "SELECT * FROM admin WHERE admin_id = '$_SESSION[admin_id]'");
								while ($row = mysqli_fetch_array($select)) {
							?>

							<p><?php echo $row['admin_firstname'] ." " .$row['admin_lastname'] ." - " .$row['admin_type']; ?></p>
							
							<?php
								}
							?>
						</td>
						<td><img src="profile.png"></td>
					</tr>
				</table>	
			</div>
		</div>
		<div id="sidebar">
			<nav class="navbar">
				<a class="btn"><i class="fas fa-bars"></i></a>
				<div class="menu">
					<div class="item active"><a href="dashboard-admin.php"><i class="fas fa-desktop"></i>Dashboard</a></div>
					<div class="item">
						<a class="sub-btn"><i class="fa-solid fa-users"></i>Users <i class="fas fa-angle-right dropdown"></i></a>
						<div class="sub-menu">
							<a href="office-head-admin.php" class="sub-item">Office Heads</a>
							<a href="guard-admin.php" class="sub-item">Guards</a>
						</div>
					</div>
					<div class="item">
						<a class="sub-btn"><i class="fas fa-gear"></i>Settings <i class="fas fa-angle-right dropdown"></i></a>
						<div class="sub-menu">
							<a href="setting.php" class="sub-item">General Settings</a>
							<a href="password.php" class="sub-item">Change Password</a>
							<a href="holiday.php" class="sub-item">Add Holidays</a>
						</div>
					</div>
					<div class="item"><a href="signout.php"><i class="fa-solid fa-right-from-bracket"></i></i>Sign Out</a></div>
				</div>
			</nav>
		</div>
		<script type="text/javascript">
			$(document).ready(function(){
				$('.sub-btn').click(function(){
					$(this).next('.sub-menu').slideToggle();
					$(this).find('.dropdown').toggleClass('rotate');
				});
			});
			$(document).ready(function(){
				$('.btn').click(function(){
					$(this).next('.menu').slideToggle();
				});
			});
		</script>
		<div id="content1">
			<center>
				<table>
					<tr>
						<td class="icon"><i class="fa-solid fa-user-check"></i></td>
						<td>
							<p>Total number of registered Users</p>
							<div id="total">
								<?php
									$count_data = mysqli_query($connection, "SELECT * FROM user WHERE user_status = 'verified'");
									$count = mysqli_num_rows($count_data);

									echo "<p>" .$count ."</p>";
								?>
							</div>
						</td>
					</tr>
				</table>
			</center>
		</div>
		<div id="content2">
			<center>
				<table>
					<tr>
						<td class="icon"><i class="fa-solid fa-user-group"></i></td>
						<td>
							<p>Total number of Guards</p>
							<div id="total">
								<?php
									$count_data = mysqli_query($connection, "SELECT * FROM admin WHERE admin_type = 'Guard' AND admin_branch = '$_SESSION[admin_branch]'");
									$count = mysqli_num_rows($count_data);

									echo "<p>" .$count ."</p>";
								?>
							</div>
						</td>
					</tr>
				</table>
			</center>
		</div>
		<div id="content3">
			<center>
				<table>
					<tr>
						<td class="icon"><i class="fa-solid fa-user-group"></i></td>
						<td>
							<p>Total number of Office Heads</p>
							<div id="total">
								<?php
									$count_data = mysqli_query($connection, "SELECT * FROM admin WHERE admin_type = 'Office Head' AND admin_branch = '$_SESSION[admin_branch]'");
									$count = mysqli_num_rows($count_data);

									echo "<p>" .$count ."</p>";
								?>
							</div>
						</td>
					</tr>
				</table>
			</center>
		</div>
		<div id="graph">
			<div id="users">
				<p>Users</p>
				<table align="center">
					<tr>
						<td>
							<p class="title">Verified Users</p>
						</td>
						<td></td>
						<td><p class="title">Non-Verified Users</p></td>
					</tr>
					<tr>
						<td id="td-user">
							<div>
								<?php
									$count_data = mysqli_query($connection, "SELECT * FROM user WHERE user_status = 'verified'");
									$count = mysqli_num_rows($count_data);

									echo "<p class='total-count verified'>" .$count ."</p>";
								?>
							</div>
						</td>
						<td id="emp"></td>
						<td id="td-user">
							<div>
								<?php
									$count_data = mysqli_query($connection, "SELECT * FROM user WHERE user_status = 'notverified'");
									$count = mysqli_num_rows($count_data);

									echo "<p class='total-count nonverified'>" .$count ."</p>";
								?>
							</div>
						</td>
					</tr>
				</table>
			</div>
			<div id="appointment">
				<p>Overall Appointments</p>
				<table align="center">
					<tr>
						<td class="td-status">Pending</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT * FROM appointments WHERE appointment_status = 'Pending' AND appointment_branch = '$_SESSION[admin_branch]'");
								$count = mysqli_num_rows($count_data);

								echo $count;
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">Accepted</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT * FROM appointments WHERE appointment_status = 'Accepted' AND appointment_branch = '$_SESSION[admin_branch]'");
								$count = mysqli_num_rows($count_data);

								echo $count;
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">Declined</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT * FROM appointments WHERE appointment_status = 'Declined' AND appointment_branch = '$_SESSION[admin_branch]'");
								$count = mysqli_num_rows($count_data);

								echo $count;
							?>
						</td>
					</tr>
				</table>
			</div>
			<div id="monthly">
				<p>Monthly Pending Appointments</p>
				<table align="center">
					<tr>
						<td class="td-status">January</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=01 AND appointment_status = 'Pending' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">February</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=02 AND appointment_status = 'Pending' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">March</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=03 AND appointment_status = 'Pending' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">April</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=04 AND appointment_status = 'Pending' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">May</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=05 AND appointment_status = 'Pending' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">June</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=06 AND appointment_status = 'Pending' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">July</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=07 AND appointment_status = 'Pending' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">August</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=08 AND appointment_status = 'Pending' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">September</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=09 AND appointment_status = 'Pending' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">October</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=10 AND appointment_status = 'Pending' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">November</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=11 AND appointment_status = 'Pending' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">December</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=12 AND appointment_status = 'Pending' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
				</table>
			</div>
			<div id="monthly">
				<p>Monthly Accepted Appointments</p>
				<table align="center">
					<tr>
						<td class="td-status">January</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=01 AND appointment_status = 'Accepted' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">February</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=02 AND appointment_status = 'Accepted' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">March</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=03 AND appointment_status = 'Accepted' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">April</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=04 AND appointment_status = 'Accepted' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">May</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=05 AND appointment_status = 'Accepted' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">June</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=06 AND appointment_status = 'Accepted' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">July</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=07 AND appointment_status = 'Accepted' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">August</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=08 AND appointment_status = 'Accepted' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">September</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=09 AND appointment_status = 'Accepted' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">October</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=10 AND appointment_status = 'Accepted' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">November</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=11 AND appointment_status = 'Accepted' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">December</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=12 AND appointment_status = 'Accepted' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
				</table>
			</div>
			<div id="monthly">
				<p>Monthly Declined Appointments</p>
				<table align="center">
					<tr>
						<td class="td-status">January</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=01 AND appointment_status = 'Declined' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">February</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=02 AND appointment_status = 'Declined' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">March</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=03 AND appointment_status = 'Declined' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">April</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=04 AND appointment_status = 'Declined' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">May</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=05 AND appointment_status = 'Declined' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">June</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=06 AND appointment_status = 'Declined' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">July</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=07 AND appointment_status = 'Declined' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">August</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=08 AND appointment_status = 'Declined' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">September</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=09 AND appointment_status = 'Declined' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">October</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=10 AND appointment_status = 'Declined' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">November</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=11 AND appointment_status = 'Declined' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">December</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE month(appointment_date)=12 AND appointment_status = 'Declined' AND appointment_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
				</table>
			</div>
		</div>
		<div id="footer"></div>
	</div>
</body>
</html>