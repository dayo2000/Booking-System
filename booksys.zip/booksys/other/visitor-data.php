<?php
	ob_start();
	require_once "add-data.php";
	$messages = array();
	$errors = array();
	$error = array();

	if (isset($_POST['update'])) {
		$id = mysqli_real_escape_string($connection, $_POST['id']);
		$name = mysqli_real_escape_string($connection, $_POST['name']);
		$purpose = mysqli_real_escape_string($connection, $_POST['purpose']);
		$destination = mysqli_real_escape_string($connection, $_POST['destination']);
		$date = mysqli_real_escape_string($connection, $_POST['date']);
		$timeentry = mysqli_real_escape_string($connection, $_POST['timeentry']);
		$timeexit = mysqli_real_escape_string($connection, $_POST['timeexit']);

		$pattern_name = "/^[\s|0-9]*$/";
     	if (preg_match($pattern_name, $name) == 0) {
      		$name_validation = "Valid";
      	} else
      		$name_validation = "Invalid";

		$pattern_pd = "/^.{1,100}$/";
    	if (preg_match($pattern_pd, $purpose)) {
      		$purpose_validation = "Valid";
      	} else
      		$purpose_validation = "Invalid";

		if (preg_match($pattern_pd, $destination)) {
      		$destination_validation = "Valid";
      	} else
      		$destination_validation = "Invalid";

		$pattern_date = "/^.{1,30}$/";
    	if (preg_match($pattern_date, $date)) {
      		$date_validation = "Valid";
      	} else
      		$date_validation = "Invalid";

		$pattern_time = "/^.{1,10}$/";
      	if (preg_match($pattern_time, $timeentry)) {
      		$timeentry_validation = "Valid";
      	} else
      		$timeentry_validation = "Invalid";

      	if (preg_match($pattern_time, $timeexit)) {
      		$timeexit_validation = "Valid";
      	} else
      		$timeexit_validation = "Invalid";

      	if ($name_validation == "Valid" && $purpose_validation == "Valid" && $destination_validation == "Valid" && $date_validation == "Valid" && $timeentry_validation == "Valid" && $timeexit_validation == "Valid") {
      		$update_data = mysqli_query($connection, "UPDATE logs SET log_name = '$name', log_purpose = '$purpose', log_destination = '$destination', log_date = '$date', log_timeentry = '$timeentry', log_timeexit = '$timeexit' WHERE log_id = '$id'");
      		if ($update_data) {
      			echo "<script>alert('Log successfully updated!');window.location.href='visitors.php'</script>";
      		} else{
      			$error['db-error'] = "Something went wrong!";
      		}
      	} else{
      		$error['db-error'] = "Invalid input(s)!";
      	}
	}

	if(isset($_GET['delete'])) {
		$log_id = $_GET['delete'];
		$delete_data = mysqli_query($connection, "DELETE FROM logs WHERE log_id = '$log_id'");
		
		if ($delete_data){
		    $messages['info'] = "Log successfully deleted!";
		} else{
		    $errors['db-error'] = "Failed while deleting data in the database!";
		}
	}
?>