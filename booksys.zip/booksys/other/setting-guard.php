<?php
	require_once "add-data.php";
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>General Settings</title>
	<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<script type="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="setting.css">
</head>
<body>
	<div class="container">
		<div id="header">
			<div id="header-content">
				<table>
					<tr>
						<td>
							<?php
								$select = mysqli_query($connection, "SELECT * FROM admin WHERE admin_id = '$_SESSION[admin_id]'");
								while ($row = mysqli_fetch_array($select)) {
							?>

							<p><?php echo $row['admin_firstname'] ." " .$row['admin_lastname'] ." - " .$row['admin_type']; ?></p>
							
							<?php
								}
							?>
						</td>
						<td><img src="profile.png"></td>
					</tr>
				</table>	
			</div>
		</div>
		<div id="sidebar">
			<nav>
				<a class="btn"><i class="fas fa-bars"></i></a>
				<div class="menu">
					<div class="item"><a href="dashboard-guard.php"><i class="fas fa-desktop"></i>Dashboard</a></div>
					<div class="item"><a href="qrscanner.php"><i class="fa-solid fa-qrcode"></i>QR Code Scanner</a></div>
					<div class="item">
						<a class="sub-btn"><i class="fas fa-table"></i>Requests <i class="fas fa-angle-right dropdown"></i></a>
						<div class="sub-menu">
							<a href="request-pending-guard.php" class="sub-item">Pending</a>
							<a href="request-accept-guard.php" class="sub-item">Accepted</a>
							<a href="request-decline-guard.php" class="sub-item">Declined</a>
						</div>
					</div>
					<div class="item"><a href="logs.php"><i class="fa-solid fa-book"></i>Logs</a></div>
					<div class="item"><a href="visitors.php"><i class="fa-solid fa-users"></i>Visitors</a></div>
					<div class="item">
						<a class="sub-btn"><i class="fas fa-gear"></i>Settings <i class="fas fa-angle-right dropdown"></i></a>
						<div class="sub-menu">
							<a href="setting-guard.php" class="sub-item active">General Settings</a>
							<a href="password-guard.php" class="sub-item">Change Password</a>
						</div>
					</div>
					<div class="item"><a href="signout.php"><i class="fa-solid fa-right-from-bracket"></i>Sign Out</a></div>
				</div>
			</nav>
		</div>
		<script type="text/javascript">
			$(document).ready(function(){
				$('.sub-btn').click(function(){
					$(this).next('.sub-menu').slideToggle();
					$(this).find('.dropdown').toggleClass('rotate');
				});
			});
			$(document).ready(function(){
				$('.btn').click(function(){
					$(this).next('.menu').slideToggle();
				});
			});
		</script>
		<div id="searchbar">
			<h2>General Settings</h2>
		</div>
		<div id="update">
			<a href="update-info-guard.php"><i class="fa-solid fa-pencil"></i> Update Information</a>
		</div>
		<div id="table">
			<table>
				<?php
					$select = mysqli_query($connection, "SELECT * FROM admin WHERE admin_id = '$_SESSION[admin_id]'");
					while ($row = mysqli_fetch_array($select)) {
				?>
				<tr>
					<td class="td-name">Name</td>
					<td class="td-content"><?php echo $row['admin_firstname'] ." " .$row['admin_lastname']; ?></td>
				</tr>
				<tr>
					<td class="td-name">Campus</td>
					<td class="td-content"><?php echo $row['admin_branch']; ?></td>
				</tr>
				<tr>
					<td class="td-name">User Role</td>
					<td class="td-content"><?php echo $row['admin_type']; ?></td>
				</tr>
				<tr>
					<td class="td-name">Email</td>
					<td class="td-content"><?php echo $row['admin_email']; ?></td>
				</tr>
				<?php
					}
				?>
			</table>
		</div>
		<div id="footer"></div>
	</div>
</body>
</html>