<?php
	include("connection.php");
	
	session_start();
	$errors = array();

	//If user click sign in
	if (isset($_POST['signin'])) {
	    $email = mysqli_real_escape_string($connection, $_POST['email']);
	    $password = mysqli_real_escape_string($connection, $_POST['password']);
	    $check_email = "SELECT * FROM admin WHERE admin_email = '$email'";
	    $res = mysqli_query($connection, $check_email);
	    if(mysqli_num_rows($res) > 0){
	        $fetch = mysqli_fetch_assoc($res);
	        $fetch_pass = $fetch['admin_password'];
	        if(password_verify($password, $fetch_pass)){
	            $type = $fetch['admin_type'];
	            $status = $fetch['admin_status'];
	            if ($type == 'Office Head') {
	            	if ($status == 'active') {
	            		$id = $fetch['admin_id'];
	            		$branch = $fetch['admin_branch'];
	            		$_SESSION['admin_id'] = $id;
	                	$_SESSION['admin_email'] = $email;
	                	$_SESSION['admin_password'] = $password;
	                	$_SESSION['admin_branch'] = $branch;
	                	header('location: dashboard-head.php');
	                	exit();
	            	} else if ($status == 'inactive') {
	            		$id = $fetch['admin_id'];
	            		$branch = $fetch['admin_branch'];
	            		$update_data = mysqli_query($connection, "UPDATE admin SET admin_status = 'active' WHERE admin_id = '$id'");
	            		if ($update_data) {
	            			$_SESSION['admin_id'] = $id;
	                		$_SESSION['admin_email'] = $email;
	                		$_SESSION['admin_password'] = $password;
	                		$_SESSION['admin_branch'] = $branch;
	                		header('location: dashboard-head.php');
	                		exit();
	            		}else {
	            			$errors['inactive'] = "Your account is inactive!";
	            		}
	            	} else if ($status == 'lock') {
	            		$errors['lock'] = "Your account is locked!";
	            	}
	            }else if ($type == 'Guard') {
	            	if ($status == 'active') {
	            		$id = $fetch['admin_id'];
	            		$branch = $fetch['admin_branch'];
	            		$_SESSION['admin_id'] = $id;
	                	$_SESSION['admin_email'] = $email;
	                	$_SESSION['admin_password'] = $password;
	                	$_SESSION['admin_branch'] = $branch;
	                	header('location: dashboard-guard.php');
	                	exit();
	            	} else if ($status == 'inactive') {
	            		$id = $fetch['admin_id'];
	            		$branch = $fetch['admin_branch'];
	            		$update_data = mysqli_query($connection, "UPDATE admin SET admin_status = 'active' WHERE admin_id = '$id'");
	            		if ($update_data) {
	            			$_SESSION['admin_id'] = $id;
	                		$_SESSION['admin_email'] = $email;
	                		$_SESSION['admin_password'] = $password;
	                		$_SESSION['admin_branch'] = $branch;
	                		header('location: dashboard-guard.php');
	                		exit();
	            		}else {
	            			$errors['inactive'] = "Your account is inactive!";
	            		}
	            	} else if ($status == 'lock') {
	            		$errors['lock'] = "Your account is locked!";
	            	}
	            }
	        }else {
	            $errors['email'] = "Incorrect email or password!";
	        }
	    }else {
	        $errors['email'] = "Account doesn't exist!";
	    }
	}
?>