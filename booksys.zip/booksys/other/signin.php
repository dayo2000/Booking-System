<?php
	require_once "signin-data.php";
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Sign In</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrint-tofit=no">
	<script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<link rel="stylesheet" type="text/css" href="signin.css">
</head>
<body>
	<div class="container">
		<div id="left">
			<div id="content">
				<center>
					<form method="post">
						<img src="logo.png">
						<h1>NUEVA ECIJA UNIVERSITY</h1>
						<h1>OF SCIENCE AND TECHNOLOGY</h1>
						<br/>
						<h2>SIGN IN</h2>
						<input type="email" name="email" maxlength="50" placeholder="Email Address" required="">
						<input type="password" name="password" maxlength="12" placeholder="Password" required="">
						<input type="submit" name="signin" value="SIGN IN">
						<?php
							if(count($errors) > 0){
						?>
						<div class="alert alert-danger text-center" style="padding: 15px; margin-top: 2%; font-size: 14px; background-color: #FFCDD2; color: #C62828; width: 45%;">
							<?php
						        foreach($errors as $showerror){
						            echo $showerror;
						        }
					        ?>
						</div>
						<?php
							}
						?>
					</form>
				</center>
			</div>
		</div>
		<div id="right"></div>
	</div>
</body>
</html>