<?php
	require "session.php";
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Dashboard</title>
	<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<script type="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="dashboard.css">
</head>
<body>
	<div class="container">
		<div id="header">
			<div id="header-content">
				<table>
					<tr>
						<td>
							<?php
								$select = mysqli_query($connection, "SELECT * FROM admin WHERE admin_id = '$_SESSION[admin_id]'");
								while ($row = mysqli_fetch_array($select)) {
							?>

							<p><?php echo $row['admin_firstname'] ." " .$row['admin_lastname'] ." - " .$row['admin_type']; ?></p>
							
							<?php
								}
							?>
						</td>
						<td><img src="profile.png"></td>
					</tr>
				</table>	
			</div>
		</div>
		<div id="sidebar">
			<nav class="navbar">
				<a class="btn"><i class="fas fa-bars"></i></a>
				<div class="menu">
					<div class="item active"><a href="dashboard-guard.php"><i class="fas fa-desktop"></i>Dashboard</a></div>
					<div class="item"><a href="qrscanner.php"><i class="fa-solid fa-qrcode"></i>QR Code Scanner</a></div>
					<div class="item">
						<a class="sub-btn"><i class="fas fa-table"></i>Requests <i class="fas fa-angle-right dropdown"></i></a>
						<div class="sub-menu">
							<a href="request-pending-guard.php" class="sub-item">Pending</a>
							<a href="request-accept-guard.php" class="sub-item">Accepted</a>
							<a href="request-decline-guard.php" class="sub-item">Declined</a>
						</div>
					</div>
					<div class="item"><a href="logs.php"><i class="fa-solid fa-book"></i>Logs</a></div>
					<div class="item"><a href="visitors.php"><i class="fa-solid fa-users"></i>Visitors</a></div>
					<div class="item">
						<a class="sub-btn"><i class="fas fa-gear"></i>Settings <i class="fas fa-angle-right dropdown"></i></a>
						<div class="sub-menu">
							<a href="setting-guard.php" class="sub-item">General Settings</a>
							<a href="password-guard.php" class="sub-item">Change Password</a>
						</div>
					</div>
					<div class="item"><a href="signout.php"><i class="fa-solid fa-right-from-bracket"></i></i>Sign Out</a></div>
				</div>
			</nav>
		</div>
		<script type="text/javascript">
			$(document).ready(function(){
				$('.sub-btn').click(function(){
					$(this).next('.sub-menu').slideToggle();
					$(this).find('.dropdown').toggleClass('rotate');
				});
			});
			$(document).ready(function(){
				$('.btn').click(function(){
					$(this).next('.menu').slideToggle();
				});
			});
		</script>
		<div id="content1">
			<center>
				<table>
					<tr>
						<td class="icon"><i class="fa-solid fa-users"></i></td>
						<td>
							<p>Total number of Logs</p>
							<div id="total">
								<?php
									$count_data = mysqli_query($connection, "SELECT * FROM logs WHERE log_branch = '$_SESSION[admin_branch]'");
									$count = mysqli_num_rows($count_data);

									echo "<p>" .$count ."</p>";
								?>
							</div>
						</td>
					</tr>
				</table>
			</center>
		</div>
		<div id="content2">
			<center>
				<table>
					<tr>
						<td class="icon"><i class="fa-solid fa-user-group"></i></td>
						<td>
							<p>People in school right now</p>
							<div id="total">
								<?php
									$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM logs WHERE log_date=CURDATE() AND log_branch = '$_SESSION[admin_branch]'");
									$result = mysqli_fetch_assoc($count_data);
									$counted = $result['count'];

									echo "<p><a class='count' href='visitors.php'>" .$counted ."</a></p>";
								?>
							</div>
						</td>
					</tr>
				</table>
			</center>
		</div>
		<div id="content3">
			<center>
				<table>
					<tr>
						<td class="icon"><i class="fas fa-calendar-day"></i></td>
						<td>
							<p>Accepted request for the day</p>
							<div id="total">
								<?php
									$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM appointments WHERE appointment_date=CURDATE() AND appointment_status = 'Accepted' AND appointment_branch = '$_SESSION[admin_branch]'");
									$result = mysqli_fetch_assoc($count_data);
									$counted = $result['count'];

									echo "<p>" .$counted ."</p>";
								?>
							</div>
						</td>
					</tr>
				</table>
			</center>
		</div>
		<div id="graph">
			<div id="appointment">
				<p><a href="visitors.php">Today's Log</a></p>
				<table align="center">
					<tr>
						<td class="td-status">Logs</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM logs WHERE log_date=CURDATE() AND log_branch = '$_SESSION[admin_branch]'");
								$result = mysqli_fetch_assoc($count_data);
								$counted = $result['count'];

								echo $counted;
							?>
						</td>
					</tr>
				</table>
			</div>
			<div id="appointment">
				<p><a href="logs.php">Overall Logs</a></p>
				<table align="center">
					<tr>
						<td class="td-status">Logs</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT * FROM logs WHERE log_branch = '$_SESSION[admin_branch]'");
								$count = mysqli_num_rows($count_data);

								echo $count;
							?>
						</td>
					</tr>
				</table>
			</div>
			<div id="appointment">
				<p>Overall Appointments</p>
				<table align="center">
					<tr>
						<td class="td-status">Pending</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT * FROM appointments WHERE appointment_status = 'Pending' AND appointment_branch = '$_SESSION[admin_branch]'");
								$count = mysqli_num_rows($count_data);

								echo $count;
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">Accepted</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT * FROM appointments WHERE appointment_status = 'Accepted' AND appointment_branch = '$_SESSION[admin_branch]'");
								$count = mysqli_num_rows($count_data);

								echo $count;
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">Declined</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT * FROM appointments WHERE appointment_status = 'Declined' AND appointment_branch = '$_SESSION[admin_branch]'");
								$count = mysqli_num_rows($count_data);

								echo $count;
							?>
						</td>
					</tr>
				</table>
			</div>
			<div id="monthly">
				<p>Monthly Logs</p>
				<table align="center">
					<tr>
						<td class="td-status">January</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM logs WHERE month(log_date)=01 AND log_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">February</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM logs WHERE month(log_date)=02 AND log_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">March</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM logs WHERE month(log_date)=03 AND log_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">April</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM logs WHERE month(log_date)=04 AND log_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">May</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM logs WHERE month(log_date)=05 AND log_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">June</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM logs WHERE month(log_date)=06 AND log_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">July</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM logs WHERE month(log_date)=07 AND log_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">August</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM logs WHERE month(log_date)=08 AND log_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">September</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM logs WHERE month(log_date)=09 AND log_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">October</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM logs WHERE month(log_date)=10 AND log_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">November</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM logs WHERE month(log_date)=11 AND log_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
					<tr>
						<td class="td-status">December</td>
						<td class="td-line">
							<hr/>
						</td>
						<td class="td-appointment">
							<?php
								$count_data = mysqli_query($connection, "SELECT count(*) AS count FROM logs WHERE month(log_date)=12 AND log_branch = '$_SESSION[admin_branch]'");
								$row = mysqli_fetch_assoc($count_data);

								echo $row['count'];
							?>
						</td>
					</tr>
				</table>
			</div>
		</div>
		<div id="footer"></div>
	</div>
</body>
</html>