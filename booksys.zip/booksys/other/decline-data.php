<?php
	require "session.php";
	$messages = array();
	$errors = array();

	if(isset($_GET['delete'])) {
		$id = $_GET['delete'];
		$delete_data = mysqli_query($connection, "DELETE FROM appointments WHERE id = '$id'");
		
		if ($delete_data){
		    $_SESSION['info'] = "User request has been deleted!";
		} else{
		    $errors['db-error'] = "Failed while deleting data in the database!";
		}
	}
?>