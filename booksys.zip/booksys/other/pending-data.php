<?php
	require "session.php";
	$messages = array();
	$errors = array();
	$error = array();

	if(isset($_GET['accept'])) {
		$id = $_GET['accept'];
		$status = "Accepted";
		$update_data = mysqli_query($connection, "UPDATE appointments SET appointment_status = '$status' WHERE id = '$id'");
	
		if ($update_data){
		    $messages['info'] = "User request has been accepted!";
		} else{
		    $errors['db-error'] = "Failed while updating data in the database!";
		}
	}

	if(isset($_GET['decline'])) {
		$id = $_GET['decline'];
		$status = "Declined";
		$update_data = mysqli_query($connection, "UPDATE appointments SET appointment_status = '$status' WHERE id = '$id'");
	
		if ($update_data){
	    	$messages['info'] = "User request has been declined!";
		} else{
	   		$errors['db-error'] = "Failed while updating data in the database!";
		}
	}

	if (isset($_POST['update'])) {
		$id = mysqli_real_escape_string($connection, $_POST['id']);
		$purpose = mysqli_real_escape_string($connection, $_POST['purpose']);
		$destination = mysqli_real_escape_string($connection, $_POST['destination']);
		$date = mysqli_real_escape_string($connection, $_POST['date']);
		$time = mysqli_real_escape_string($connection, $_POST['time']);

		$pattern_pd = "/^.{1,100}$/";
     	if (preg_match($pattern_pd, $purpose)) {
      		$purpose_validation = "Valid";
      	} else
      		$purpose_validation = "Invalid";

		if (preg_match($pattern_pd, $destination)) {
      		$destination_validation = "Valid";
      	} else
      		$destination_validation = "Invalid";

		$pattern_date = "/^.{1,30}$/";
     	if (preg_match($pattern_date, $date)) {
      		$date_validation = "Valid";
      	} else
      		$date_validation = "Invalid";

		$pattern_time = "/^[A-Z]{2}$/";
     	if (preg_match($pattern_time, $time)) {
      		$time_validation = "Valid";
      	} else
      		$time_validation = "Invalid";

      	if ($purpose_validation == "Valid" && $destination_validation == "Valid" && $date_validation == "Valid" && $time_validation == "Valid") {
      		$update_data = mysqli_query($connection, "UPDATE appointments SET appointment_purpose = '$purpose', appointment_destination = '$destination', appointment_date = '$date', appointment_sched = '$time' WHERE id = '$id'");
      		if ($update_data) {
      			echo "<script>alert('Request successfully updated!');window.location.href='request-pending-head.php'</script>";
      		} else{
      			$error['db-error'] = "Something went wrong!";
      		}
      	} else{
      		$error['db-error'] = "Invalid input(s)!";
      	}
	}

	if(isset($_GET['delete'])) {
		$id = $_GET['delete'];
		$delete_data = mysqli_query($connection, "DELETE FROM appointments WHERE id = '$]id'");
		
		if ($delete_data){
		    $messages['info'] = "User request has been deleted!";
		} else{
		    $errors['db-error'] = "Failed while deleting data in the database!";
		}
	}
?>