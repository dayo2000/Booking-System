<?php
	include("connection.php");
	include("session.php");
	$errors = array();

	//If admin (guard) click log
	if (isset($_POST['log'])) {
		$name = mysqli_real_escape_string($connection, $_POST['name']);
		$purpose = mysqli_real_escape_string($connection, $_POST['purpose']);
		$destination = mysqli_real_escape_string($connection, $_POST['destination']);
		$date = mysqli_real_escape_string($connection, $_POST['date']);
		$timeentry = mysqli_real_escape_string($connection, $_POST['time-in']);
		$branch = $_SESSION['admin_branch'];

		$pattern_name = "/^[\s|0-9]*$/";
      	if (preg_match($pattern_name, $name) == 0) {
      		$name_validation = "Valid";
      	} else
      		$name_validation = "Invalid";

		$pattern_pd = "/^.{1,100}$/";
      	if (preg_match($pattern_pd, $purpose)) {
      		$purpose_validation = "Valid";
      	} else
      		$purpose_validation = "Invalid";

		if (preg_match($pattern_pd, $destination)) {
      		$destination_validation = "Valid";
      	} else
      		$destination_validation = "Invalid";

		$pattern_date = "/^.{1,30}$/";
      	if (preg_match($pattern_date, $date)) {
      		$date_validation = "Valid";
      	} else
      		$date_validation = "Invalid";

		$pattern_timeentry = "/^.{1,10}$/";
      	if (preg_match($pattern_timeentry, $timeentry)) {
      		$timeentry_validation = "Valid";
      	} else
      		$timeentry_validation = "Invalid";

      	if ($name_validation == "Valid" && $purpose_validation == "Valid" && $destination_validation == "Valid" && $date_validation == "Valid" && $timeentry_validation == "Valid") {
      		$insert_data = mysqli_query($connection, "INSERT INTO logs (log_name, log_purpose, log_destination, log_date, log_timeentry, log_branch) VALUES ('$name', '$purpose', '$destination', '$date', '$timeentry', '$branch')");
      		if ($insert_data){
      			echo "<script>alert('Log successfully added!');window.location.href='logs.php'</script>";
      		} else{
      			$errors['db-error'] = "Failed while inserting data in the database!";
      		}
      	} else{
      		$errors['validation-error'] = "Invalid input(s)!";
      	}
	}
?>