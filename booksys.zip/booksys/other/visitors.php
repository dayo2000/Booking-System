<?php
	ob_start();
	require "visitor-data.php";
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Visitors</title>
	<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<script type="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="visitors.css">
</head>
<body>
	<div class="container">
		<div id="header">
			<div id="header-content">
				<table>
					<tr>
						<td>
							<?php
								$select = mysqli_query($connection, "SELECT * FROM admin WHERE admin_id = '$_SESSION[admin_id]'");
								while ($row = mysqli_fetch_array($select)) {
							?>

							<p><?php echo $row['admin_firstname'] ." " .$row['admin_lastname'] ." - " .$row['admin_type']; ?></p>
							
							<?php
								}
							?>
						</td>
						<td><img src="profile.png"></td>
					</tr>
				</table>	
			</div>
		</div>
		<div id="sidebar">
			<nav>
				<a class="btn"><i class="fas fa-bars"></i></a>
				<div class="menu">
					<div class="item"><a href="dashboard-guard.php"><i class="fas fa-desktop"></i>Dashboard</a></div>
					<div class="item"><a href="qrscanner.php"><i class="fa-solid fa-qrcode"></i>QR Code Scanner</a></div>
					<div class="item">
						<a class="sub-btn"><i class="fas fa-table"></i>Requests <i class="fas fa-angle-right dropdown"></i></a>
						<div class="sub-menu">
							<a href="request-pending-guard.php" class="sub-item">Pending</a>
							<a href="request-accept-guard.php" class="sub-item">Accepted</a>
							<a href="request-decline-guard.php" class="sub-item">Declined</a>
						</div>
					</div>
					<div class="item"><a href="logs.php"><i class="fa-solid fa-book"></i>Logs</a></div>
					<div class="item active"><a href="visitors.php"><i class="fa-solid fa-users"></i>Visitors</a></div>
					<div class="item">
						<a class="sub-btn"><i class="fas fa-gear"></i>Settings <i class="fas fa-angle-right dropdown"></i></a>
						<div class="sub-menu">
							<a href="setting-guard.php" class="sub-item">General Settings</a>
							<a href="password-guard.php" class="sub-item">Change Password</a>
						</div>
					</div>
					<div class="item"><a href="signout.php"><i class="fa-solid fa-right-from-bracket"></i>Sign Out</a></div>
				</div>
			</nav>
		</div>
		<script type="text/javascript">
			$(document).ready(function(){
				$('.sub-btn').click(function(){
					$(this).next('.sub-menu').slideToggle();
					$(this).find('.dropdown').toggleClass('rotate');
				});
			});
			$(document).ready(function(){
				$('.btn').click(function(){
					$(this).next('.menu').slideToggle();
				});
			});
		</script>
		<div id="searchbar">
			<div id="searchbar-form" hidden>
				<form method="post">
					<input type="text" name="search-data" placeholder="Search">
					<input type="submit" name="search" value="Search">
				</form>
			</div>
		</div>
		<div id="table">
			<div>
				<?php
					if(count($messages) > 0){
			    ?>
				    <div class="alert alert-danger text-center" style="display: block; width: auto; padding: 15px; color: #388E3C; margin: 0 0 10px 0; background-color: #C8E6C9; font-size: 14px;">
				        <?php
					        foreach($messages as $showmessage){
					            echo $showmessage;
					        }
				        ?>
				    </div>
			    <?php
					} else if(count($errors) > 0){
				?>
					<div class="alert alert-danger text-center" style="display: block; width: auto; padding: 15px; color: #C62828; margin: 0 0 10px 0; background-color: #FFCDD2; font-size: 14px;">
				        <?php
					        foreach($errors as $showerror){
					            echo $showerror;
					        }
				        ?>
				    </div>
				<?php
					}
				?>
				<table align="center">
					<thead>
						<tr>
							<th>ID</th>
							<th>Name</th>
							<th>Purpose</th>
							<th>Destination</th>
							<th>Date</th>
							<th>Time of Entry</th>
							<th>Time of Exit</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<?php
							$select_data = "SELECT * FROM logs WHERE log_date=CURDATE() AND log_branch = '$_SESSION[admin_branch]'";
							$result = $connection->query($select_data);

							if ($result->num_rows > 0) {
								while ($row = $result->fetch_assoc()) {
									$date = $row['log_date'];
									$dateToPrint = date('F j, Y', strtotime($date));

									$timeentry = $row['log_timeentry'];
									$timeentryToPrint = date('g:i A', strtotime($timeentry));

									$timeexit = $row['log_timeexit'];
									$timeexitToPrint = date('g:i A', strtotime($timeexit));

									echo "<tr><td>" .$row['log_id'] ."</td>";
									echo "<td>" .$row['log_name'] ."</td>";
									echo "<td>" .$row['log_purpose'] ."</td>";
									echo "<td>" .$row['log_destination'] ."</td>";
									echo "<td>" .$dateToPrint ."</td>";
									echo "<td>" .$timeentryToPrint ."</td>";
									echo "<td>";
										if ($row['log_timeexit'] > 0) {
										  	echo "$timeexitToPrint";
										}  else{
										  	echo "-- - --";
										}
									echo "</td>";
									echo "<td>";
						?>

						<?php
									echo "<div>";
										echo "<a href='visitors.php?edit=$row[log_id]' class='click-3'><i class='fa-solid fa-pen-to-square edit'></i></a>";
										if(isset($_GET['edit'])){
											$id = $_GET['edit'];
											$select_specific = mysqli_query($connection, "SELECT * FROM logs WHERE log_id = '$id'");
											while($count = mysqli_fetch_array($select_specific)){
												echo "<div class='edit-popup'>";
						?>
													<form method="post">
														<h2>EDIT LOG</h2>
															    <?php
																	if(count($error) > 0){
																?>
																	<center>
																		<div class="alert alert-danger text-center" style="width: 50%; padding: 15px; color: #C62828; margin: 0 0 10px 0; background-color: #FFCDD2; font-size: 14px;">
																	        <?php
																		        foreach($error as $showerror){
																		            echo $showerror;
																		        }
																	        ?>
																	    </div>
																	</center>
																<?php
																	}
																?>
															<input type="text" id="user-id" name="id" value="<?php echo $count['log_id']; ?>" readonly="">
															<input type="text" name="name" maxlength="100" value="<?php echo $count['log_name']; ?>" required="">
															<input type="text" name="purpose" maxlength="100" value="<?php echo $count['log_purpose']; ?>" required="">
															<input type="text" name="destination" maxlength="100" value="<?php echo $count['log_destination']; ?>" required="">
 															<input type="date" name="date" value="<?php echo strftime('%Y-%m-%d', strtotime($count['log_date'])); ?>" required="">
															<input type="time" name="timeentry" maxlength="10" value="<?php echo date("H:i", strtotime($count['log_timeentry'])); ?>" required="">
							<?php
															if ($count['log_timeexit'] > 0) {
							?>
																<input type="time" name="timeexit" maxlength="10" value="<?php echo date("H:i", strtotime($count['log_timeexit'])); ?>" required>
							<?php
															} else{
																echo "<input type='time' name='timeexit' maxlength='10' required>";
															}
							?>
															<div class="btns">
																<a href="#" class="btn-c">Cancel</a>
																<a href="#" class="btn-u"><input type="submit" name="update" value="Update"></a>
															</div>
														</form>
						<?php
													echo "</div>";
												}
											}
										echo "</div>";
						?>
									
										<script type="text/javascript">
											$(document).ready(function(){
												$('.click-3').click(function(){
												$('.edit-popup').css({"opacity":"1", "pointer-events":"auto"});
											});
												$('.btn-c').click(function(){
													$('.edit-popup').css({"opacity":"0", "pointer-events":"none"});
												});
											});
										</script>		
										
						<?php
										echo "<div>";
											echo "<a href='visitors.php?delete=$row[log_id]' class='click-4'><i class='fa-solid fa-circle-minus delete'></i></a>";
										echo "</div>";
						?>

						<?php
									echo "</td></tr>";
								}
							} else {
								echo "<tr><td colspan='8' align='center'>No Data</td></tr>";
							}
						?>
					</tbody>
				</table>
			</div>
		</div>
		<div id="footer"></div>
	</div>
</body>
</html>